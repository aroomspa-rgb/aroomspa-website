# ARoom SPA 官方網站

這是 ARoom SPA 的靜態網站原始碼，包含首頁、服務介紹與聯絡資訊。後續可擴充為多頁式網站，並整合 AI 工具（如 Codex）輔助維護與內容生成。

## 結構說明

- `index.html`：主頁內容
- `assets/css/style.css`：樣式表
- `README.md`：專案說明
